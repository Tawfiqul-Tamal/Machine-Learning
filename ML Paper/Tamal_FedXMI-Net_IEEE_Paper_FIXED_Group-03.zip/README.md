# FedXMI-Net — IEEE Conference Paper (LaTeX source)

## Contents
```
main.tex                          Main paper file (IEEEtran, conference mode)
references.bib                    All 34 references (32 literature + 2 dataset citations)
sections/
  intro_lit_latex.tex              Introduction + Literature Review (Sections I-II)
  results.tex                      Results (Section IV)
  discussion.tex                   Discussion (Section V)
figures/                           All 11 figures used in the paper (real, executed-run outputs)
methodology_flowchart_tikz.tex     Standalone TikZ source for Fig. 1 (optional alternative
                                   to the PNG version already used in main.tex)
```

## How to compile

### Option A — Overleaf (recommended, zero setup)
1. Go to overleaf.com -> New Project -> Upload Project.
2. Upload this entire zip as-is.
3. Set the main document to `main.tex` (Overleaf usually detects this automatically).
4. Click "Recompile". Overleaf's TeX Live distribution already includes `IEEEtran.cls`
   and `IEEEtran.bst`, so no extra setup is needed.

### Option B — Local compilation
`IEEEtran.cls` and `IEEEtran.bst` are **not bundled** in this zip (their official
distribution terms ask that they be obtained directly from CTAN/IEEE rather than
redistributed by third parties). If your local TeX installation does not already
have them:

- **TeX Live**: run `tlmgr install ieeetran`, or install the `texlive-publishers`
  package via your OS package manager (e.g. `sudo apt install texlive-publishers`
  on Debian/Ubuntu).
- **MiKTeX**: it will prompt to auto-install `ieeetran` the first time you compile.
- **Manual**: download `IEEEtran.cls` and `IEEEtran.bst` from
  https://ctan.org/pkg/ieeetran and place them in the same folder as `main.tex`.

Then compile with the standard four-pass sequence (needed for citations and
cross-references to resolve):
```bash
pdflatex main.tex
bibtex main
pdflatex main.tex
pdflatex main.tex
```

## Validation performed before delivery
This LaTeX source was compiled end-to-end in a sandboxed environment using a
structurally equivalent substitute class (since the authentic IEEEtran.cls could
not be redistributed here) to verify:
- All braces, environments (`algorithm`, `table`, `figure`, `align`, `equation`)
  balance correctly and the document builds without fatal LaTeX errors.
- All 34 `\cite{}` keys resolve against `references.bib` with zero missing entries.
- All `\ref{}`/`\label{}` cross-references (sections, tables, figures, equations,
  algorithms) resolve after a full four-pass compile.
- The two-column IEEE layout, abstract, keywords, and citation numbering render
  as expected.

It was **not** compiled with the authentic `IEEEtran.cls`/`.bst` files in this
environment, so minor spacing/formatting differences from the exact final IEEE
camera-ready look are possible; the content, structure, citations, and
cross-references are verified correct regardless of which valid IEEEtran class
file is used to typeset them.

## Compiled Preview PDF
`FedXMI-Net_Compiled_Preview.pdf` (21 pages) is included so you can immediately see
the full paper's content, structure, citations, and figures without needing to
compile anything yourself.

**Important — read before judging the visual formatting:** this PDF was compiled
using a structurally equivalent *substitute* class, not the authentic
`IEEEtran.cls`, for the reason explained above (redistribution restriction).
That means:
- Font, exact column spacing, and title-block styling in this preview PDF will
  **look plainer than real IEEE camera-ready output** — no author-affiliation
  formatting, no journal-style headers, slightly different spacing.
- Everything else — section order, all body text, all 34 citations resolving
  correctly, all figures placed and captioned, all tables, all equations, all
  cross-references — is fully verified and will carry over identically once
  compiled with the real `IEEEtran.cls` on Overleaf.

**For the true, final IEEE-formatted PDF, compile `main.tex` on Overleaf** (Option A
above) — this will use the authentic IEEEtran class and produce the real
camera-ready look. The included preview PDF is a content/structure check only,
not the final visual output.

## Notes on content

- All numerical results, figures, and tables in Sections III-IV are taken directly
  from a single fully executed run of the accompanying Jupyter notebook — nothing
  is synthetic or placeholder.
- The Discussion and Conclusion sections were newly drafted for this manuscript.
- Two supplementary/in-progress experiments (a merged BCI Competition IV-2b
  federated study, and a four-class extension) are referenced in the Discussion's
  Limitations subsection but are **not** included as headline results, consistent
  with their current validation status.
